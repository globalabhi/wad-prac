export interface User {
  name: string;
  email: string;
  password: string;
  gender: string;
  branch: string;
}
